﻿namespace GuessAWordGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PlayGameButton = new System.Windows.Forms.Button();
            this.guessBox = new System.Windows.Forms.TextBox();
            this.WordLabel = new System.Windows.Forms.Label();
            this.outLabel2 = new System.Windows.Forms.Label();
            this.MsgLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.GrantTotalLabel = new System.Windows.Forms.Label();
            this.Cancelbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PlayGameButton
            // 
            this.PlayGameButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PlayGameButton.BackgroundImage")));
            this.PlayGameButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PlayGameButton.Location = new System.Drawing.Point(30, 14);
            this.PlayGameButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PlayGameButton.Name = "PlayGameButton";
            this.PlayGameButton.Size = new System.Drawing.Size(154, 124);
            this.PlayGameButton.TabIndex = 1;
            this.PlayGameButton.UseVisualStyleBackColor = true;
            this.PlayGameButton.Click += new System.EventHandler(this.PlayGameButton_Click);
            // 
            // guessBox
            // 
            this.guessBox.Location = new System.Drawing.Point(306, 228);
            this.guessBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.guessBox.Name = "guessBox";
            this.guessBox.Size = new System.Drawing.Size(55, 26);
            this.guessBox.TabIndex = 2;
            this.guessBox.Visible = false;
            // 
            // WordLabel
            // 
            this.WordLabel.AutoSize = true;
            this.WordLabel.Font = new System.Drawing.Font("Comic Sans MS", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WordLabel.Location = new System.Drawing.Point(41, 143);
            this.WordLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WordLabel.Name = "WordLabel";
            this.WordLabel.Size = new System.Drawing.Size(171, 45);
            this.WordLabel.TabIndex = 3;
            this.WordLabel.Text = "Word is: ";
            // 
            // outLabel2
            // 
            this.outLabel2.AutoSize = true;
            this.outLabel2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outLabel2.Location = new System.Drawing.Point(35, 316);
            this.outLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.outLabel2.Name = "outLabel2";
            this.outLabel2.Size = new System.Drawing.Size(149, 35);
            this.outLabel2.TabIndex = 4;
            this.outLabel2.Text = "Good Luck!!!";
            // 
            // MsgLabel
            // 
            this.MsgLabel.AutoSize = true;
            this.MsgLabel.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MsgLabel.Location = new System.Drawing.Point(192, 36);
            this.MsgLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MsgLabel.Name = "MsgLabel";
            this.MsgLabel.Size = new System.Drawing.Size(310, 39);
            this.MsgLabel.TabIndex = 5;
            this.MsgLabel.Text = "Press button to start";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 39);
            this.label1.TabIndex = 6;
            this.label1.Text = "Guess a Letter>>";
            // 
            // SubmitButton
            // 
            this.SubmitButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SubmitButton.BackgroundImage")));
            this.SubmitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SubmitButton.FlatAppearance.BorderSize = 0;
            this.SubmitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SubmitButton.Location = new System.Drawing.Point(397, 205);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(150, 80);
            this.SubmitButton.TabIndex = 7;
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click_1);
            // 
            // GrantTotalLabel
            // 
            this.GrantTotalLabel.AutoSize = true;
            this.GrantTotalLabel.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrantTotalLabel.Location = new System.Drawing.Point(85, 392);
            this.GrantTotalLabel.Name = "GrantTotalLabel";
            this.GrantTotalLabel.Size = new System.Drawing.Size(417, 35);
            this.GrantTotalLabel.TabIndex = 8;
            this.GrantTotalLabel.Text = "See how many you can get correct";
            // 
            // Cancelbutton
            // 
            this.Cancelbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Cancelbutton.BackgroundImage")));
            this.Cancelbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Cancelbutton.FlatAppearance.BorderSize = 0;
            this.Cancelbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cancelbutton.Location = new System.Drawing.Point(397, 302);
            this.Cancelbutton.Name = "Cancelbutton";
            this.Cancelbutton.Size = new System.Drawing.Size(150, 80);
            this.Cancelbutton.TabIndex = 9;
            this.Cancelbutton.UseVisualStyleBackColor = true;
            this.Cancelbutton.Click += new System.EventHandler(this.Cancelbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 448);
            this.Controls.Add(this.Cancelbutton);
            this.Controls.Add(this.GrantTotalLabel);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MsgLabel);
            this.Controls.Add(this.outLabel2);
            this.Controls.Add(this.WordLabel);
            this.Controls.Add(this.guessBox);
            this.Controls.Add(this.PlayGameButton);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Guess a word Wheel of Fortune";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button PlayGameButton;
        private System.Windows.Forms.TextBox guessBox;
        private System.Windows.Forms.Label WordLabel;
        private System.Windows.Forms.Label outLabel2;
        private System.Windows.Forms.Label MsgLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.Label GrantTotalLabel;
        private System.Windows.Forms.Button Cancelbutton;
    }
}

