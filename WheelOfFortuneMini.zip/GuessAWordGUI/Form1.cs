﻿using System;
using System.Drawing;
using System.Windows.Forms;


namespace GuessAWordGUI
{
    public partial class Form1 : Form
    {
        string originalWord;
        string selectedWord;
        string guessedWord = "";
        int foundCount = 0;
        int totaltries = 0;

        string[] words = { "software", "java", "program", "boolean", "while", "array", "loop" };
        Random RandomClass = new Random();

        Image SubmitGreyedout = Image.FromFile("images/ncsubmitbuttongreyedout.png");
        Image Submitok = Image.FromFile("images/ncsubmitbutton.png");

        Image CheatGreyedout = Image.FromFile("images/cheatgreyedout.png");
        Image CheatOK = Image.FromFile("images/cheat.png");

        public Form1()
        {
            InitializeComponent();
            PlayGameButton.Visible = true;
            SubmitButton.Visible = true;
            guessBox.Visible = true;
            setupbuttons();
        }

        public void resetAll()
        {
            outLabel2.Text = "Good Luck!!!";
            WordLabel.Text = "Word is: ";
            guessedWord = "";
            MsgLabel.Text = "";
            GrantTotalLabel.Text = "";
            guessBox.Visible = true;
            turnon();
        }

        private void PlayGameButton_Click(object sender, EventArgs e)
        {
            PlayGame();
        }
        public void PickRandWord()
        {
            int randomNumber;
            randomNumber = RandomClass.Next(0, words.Length);
            selectedWord = words[randomNumber];
            originalWord = selectedWord;

            for (int i = 0; i < selectedWord.Length; i++)
            {
                guessedWord = guessedWord + "X";
            }
            WordLabel.Text = String.Format("Word is {0}", guessedWord);

        }

        public void PlayGame()
        {
            resetAll();
            turnon();
            PickRandWord();
        }

        public void turnon()
        {
            guessBox.Enabled = true;
            SubmitButton.BackgroundImage = Submitok;
            SubmitButton.Enabled = true;
            Cancelbutton.BackgroundImage = CheatOK;
            Cancelbutton.Enabled = true;

        }
        public void turnoff()
        {
            guessBox.Enabled = false;
            SubmitButton.BackgroundImage = SubmitGreyedout;
            SubmitButton.Enabled = false;
            Cancelbutton.BackgroundImage = CheatGreyedout;
            Cancelbutton.Enabled = false;


        }
        private void SubmitButton_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(guessBox.Text))
            {
                MsgLabel.Text = "Please enter a letter!";
                return;
            }

            char letter = guessBox.Text[0];
            guessBox.Clear();
            bool letterInWord = false;

            char[] guessedWordArray = guessedWord.ToCharArray();

            for (int pos = 0; pos < selectedWord.Length; pos++)
            {
                if (selectedWord[pos] == letter)
                {
                    guessedWordArray[pos] = letter;
                    letterInWord = true;
                    foundCount = foundCount + 1;
                }
            }

            guessedWord = new string(guessedWordArray);
            WordLabel.Text = $"Word is: {guessedWord}";

            if (letterInWord)
            {
                outLabel2.Text = $"Yes! {letter} is in the word.\ntotal letters tried so far: {totaltries + 1}";
            }

            totaltries++;

            if (guessedWord == selectedWord)
            {
                GrantTotalLabel.Text = $"You got it in {totaltries} tries";
                MsgLabel.Text = $"Good Job!\nWord was {selectedWord}";
                turnoff();
            }
        }

        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            MessageBox.Show(selectedWord);
        }

        public void setupbuttons()
        {

            SubmitButton.FlatAppearance.BorderSize = 0;
            SubmitButton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            SubmitButton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            SubmitButton.BackColor = Color.Transparent;
            SubmitButton.Enabled = false;
            SubmitButton.BackgroundImage = SubmitGreyedout;

            Cancelbutton.FlatAppearance.BorderSize = 0;
            Cancelbutton.FlatAppearance.MouseDownBackColor = Color.Transparent;
            Cancelbutton.FlatAppearance.MouseOverBackColor = Color.Transparent;
            Cancelbutton.BackColor = Color.Transparent;
            Cancelbutton.Enabled = false;
            Cancelbutton.BackgroundImage = CheatGreyedout;

        }
    }
}

